﻿// cmake_sample.cpp : Defines the entry point for the application.
//

#include "cmake_sample.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	while (1);
}
